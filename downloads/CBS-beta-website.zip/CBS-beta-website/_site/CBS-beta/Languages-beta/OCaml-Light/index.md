OCaml Light
===========

OCaml Light is a core sublanguage of [OCaml], corresponding closely to 
[Caml Light] (an obsolete pedagogical functional programming language). 

Its CBS illustrates scaling up to a medium-sized language. 
The start of the specification of OCaml Light in CBS is at [OC-L-Start].


[Caml Light]: https://caml.inria.fr/caml-light/

[OCaml]: http://ocaml.org

[OC-L-Start]: OC-L-cbs/OC-L/OC-L-Start/index.html

[Ott framework]: http://www.cl.cam.ac.uk/~pes20/ott/

[Specification of Caml Light]: http://plancomps.org/taosd2015/
