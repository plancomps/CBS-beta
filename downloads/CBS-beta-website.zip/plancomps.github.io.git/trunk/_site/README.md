PLanCompS: Programming Language Components and Specifications
=============================================================

PLanCompS is an open international collaboration, continuing from an
[EPSRC-funded research project (2011-16)](http://plancomps.org).

The main activity of PLanCompS is the development of the [CBS] framework,
meta-language, and tool support, together with examples of language specification using CBS.

[CBS]: CBS-beta/index.md
