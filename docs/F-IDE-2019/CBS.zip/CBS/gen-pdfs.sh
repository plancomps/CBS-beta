#!/bin/bash

# Generates .../FILE/index.pdf from https://plancomps.github.io/.../FILE

gen_pdf() {
 echo $1
 dir=$(dirname $1)
 css=CBS-beta/CBS-Editor/cbs-pdf.css
 wkhtmltopdf --user-style-sheet $css https://plancomps.github.io/$dir $dir/index.pdf
 # Local hosts:
 # wkhtmltopdf --user-style-sheet CBS-beta/CBS-Editor/cbs-pdf.css http://localhost:4000/CBS-beta/... .../index.pdf
}
export -f gen_pdf

find $1 -name "index.md" | xargs -n1 -I{} bash -c 'gen_pdf "$@"' _ {}
