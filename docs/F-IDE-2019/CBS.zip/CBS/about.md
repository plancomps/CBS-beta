Creating a language project using CBS on SVN
============================================

Here is how to create a language project that provides an editor for a
programming language together with a translator from programs to funcons.
The language project is generated from CBS specifications of syntax and
semantics. The CBS specifications of funcons can be shared between different
language projects in the PLanCompS SVN repository using SVN externals.

This version refers to the new `CBS-beta`, `Funcons-beta`, and `Languages-beta`
folders, in preparation for the beta-release.

__N.B.__ It is now no longer necessary to include (links to) CBS specifications
inside generated translators. This not only simplifies creation of translators,
but also allows generated translator projects to be cleaned independently of the
CBS specifications.


Platform requirements
---------------------

The procedure described below has been tested on the following platforms:

* Mac OSX High Sierra (10.13.4)

* Ubuntu 16.04 and 18.04.  Pre-requisites:
    - Java.  E.g. `sudo apt-get install default-jre default-jdk icedtea-plugin`
    - Maven.  E.g. `sudo apt-get install maven maven*`
    - Maven local settings file.  See
         [online instructions](http://www.metaborg.org/en/latest/source/dev/maven.html#local-settings-file)

The following procedure should work also on previous versions of Mac OSX, and on other Linux systems.


* Spoofax-2.4 (version 2.4.1) as a
  [pre-packaged Eclipse distribution](http://www.metaborg.org/en/latest/source/install.html)

    - `Project: Build automatically` should be on (ticked).

    - You may find it helpful to make the Console output visible by selecting `Window/Show View/Console`

* CBS-Editor (PLanCompS project internal SVN: `CBS-beta/CBS-Editor`)

	- Checkout/import it into Eclipse as a *Maven* project.

* SVN Subversion 1.8

	- Subclipse can be installed from the Eclipse Marketplace.

* Funcon Interpreter (0.2.0.1)

	- To execute funcons, install the funcons-tools package from Hackage at
	`https://hackage.haskell.org/package/funcons-tools`, and configure running
	the FCT-interpreter under
	`Run: External Tools: External Tools Configurations...`
	with `Build before launch` disabled.


Creating a language project
---------------------------

As a running example, we explain how to create a translator for a language
named `LANG`. Language names should be short, start with a capital letter,
and may consist of letters, digits, and hyphens (but not underscores).

The following language names are reserved for internal use:
`CBS`, `Funcons`, `SDF` (and its variations) and `Stratego`.

The following extensions are reserved for internal files:
`ast`, `cbs`, `config`, `fct`, `sdf` (and its variations) and `str`.

The name of the folder containing the CBS specification of `LANG` and the
`LANG` translator could be simply `LANG`. Below, we use `LANG-Folder` instead,
to avoid confusion with the files and sub-folders named `LANG`.

1.  It is assumed that in the SVN repository:

    - all the CBS files for `LANG` are in the folder
    `CBS-beta/Languages-beta/LANG-Folder/LANG-cbs/LANG`;

    - `LANG/LANG-Start/LANG-Start.cbs` includes the syntax and semantics
    of a nonterminal named `start`;

    - any other files used in the CBS definition of `LANG` are in folders with
    the same name, e.g., `LANG-cbs/LANG/X/X.cbs`;

    - all the CBS files for the funcons reused for `LANG` are in the folder
    `CBS-beta/Funcons-beta`.


2.	Ensure the following file and folder names are all ignored by SVN:

    		.cache
    		.classpath
    		.project
    		.settings
    		bin
    		src-gen
    		target


3.  Link to `Funcons-beta` in the PLanCompS SVN repository:

	- Add the following `svn:externals` property to the  project `LANG-cbs`:

            Funcons-beta svn://svn.plancomps.org/resources/CBS-beta/Funcons-beta

	- Ensure that the `LANG-cbs` project has the Spoofax 'nature'.

	- Update the project from SVN, then commit the changes.

    Hovering over the references to names (and any section numbers) in the CBS
    files should now show (right-clickable) hyperlinks to their declarations.
    If not, select the project and click on `Project: Clean...`.

    If `Build automatically` is off, also select the project and click on on
    `Project: Build`.


4.	Create a Spoofax language project using Eclipse with the following settings:

	- "Project name:" (e.g.) `LANG-Editor`

	- "Use default location:"
	  + *unchecked* (to store the project in the current workspace) or
	  + *checked and showing a location __not__ already in use.*

	- "Identifier:" (e.g.) `LANGEditor`

	- "Language name:" `LANG`

	- "Version:" (e.g.) `0.1.0-SNAPSHOT`

	- "Group identifier:" (e.g.) `org.example`

	- "Extensions:" (e.g.) `l`

	and the following language option settings:

	- "Syntax type:" `SDF3`

	- "Analysis type:" `NaBL2`

	The generation options determine whether extra projects
	for storing examples and automated tests will be created.

	Open the `Console` view in Eclipse (`Window: Show View: Other...`).

	Click on `Finish` to create the project. It can take a few minutes.
	The progress is logged in the Spoofax Console.


Generating a language editor and translator
-------------------------------------------

_Note:_ Eclipse may initially flag various errors and warnings in the generated
files. The errors should all disappear when the `LANG-Editor` project has been
successfully built; some warnings (e.g., about overloaded constructors in SDF3
files) may remain, but can be ignored.

1. 	Open `LANG-cbs/LANG/LANG-Start/LANG-Start.cbs`.

	Click on `Spoofax: Generate: Language editor`.

	The Spoofax console window should report something like the following:

	    - Generating LANG components...
	    - Generating LANG-Start
	    - Generating LANG-Disambiguation
	    - Generating LANG-3
	    - Generating LANG-1
	    - Generating LANG-2
	    - Generating LANG-4
	    - Finished

	(The Spoofax build process sometimes starts before generation has completed.
	If that happens, clean the generated `LANGEditor` project before proceeding.)

	The `LANGEditor/syntax` folder should now contain the generated files
	`Funcons.sdf3` and `Stratego-LANG.sdf`, and a folder `cbs-gen` containing
	SDF3 files generated from the CBS files for the language `LANG`.

	The `LANGEditor/trans` folder should now contain the generated files
	`generate.str` and `generate.meta`, and a folder `cbs-gen` containing Stratego
	and meta files generated from the CBS files for the language `LANG`. (No files
	are generated for funcons.)

	A new folder `LANGEditor/lib` should have been created, containing the
	generated file `StrategoMix.def`.

	The `LANGEditor/editor` folder should contain the generated file `Menus.esv`.

	_Note: Never edit the generated files, as they are overwritten by `Generate: language editor`._

2. 	Update the following files:

	- Edit `editor/Main.esv` to import first the generated ESV module `Menus`.

	- Edit `trans/l.str` to import the generated Stratego module `generate`.

	- Delete the file `syntax/Common.sdf3`, which is not used by CBS.


Building and testing the generated project
------------------------------------------

* Clean and build the `LANGEditor` project.

* Open an `LANG` program file (e.g.) `test.l`.

* Click on `Spoofax: Generation: Generate funcons`.

Assuming the CBS specification of `LANG` is complete, the translation of the `LANG`
program to funcons should appear in (e.g.) `test.fct`.


Updating the generated project
------------------------------

After editing a CBS file in `LANG-cbs`, with `LANGEditor` open:

* Save the edited CBS file.

* Click on `Spoofax: Generate: Language editor`.

* Rebuild and test the `LANGEditor` project.


Executing funcon terms
----------------------

* Open an FCT file (e.g.) `test.fct`.

* Click on `Run: External tools: FCT-Interpreter`.

The final state of an execution of the funcon term should be reported in the
Console.


Generating a funcon reuse index
-------------------------------

* Open `LANG-Start.cbs`.

* Click on `Spoofax: Generate: Funcon reuse index`.

The file `LANG-Funcon-Index/LANG-Funcon-Index.cbs` should be generated,
listing all the funcons (etc.) used in `cbs/LANG` files.


Generating web pages
--------------------

* Open `LANG-Start.cbs`.

* Click on `Spoofax: Generate: Web pages`.

For each file `cbs/LANG/X/X.cbs`, the web page `cbs/LANG/X/index.html` should
be generated.

The HTML uses a relative link to load the CSS file `Funcons-beta/cbs.css`,
and relative hyperlinks from funcon names to their declarations. This requires
`Funcons-beta` to be located as a sibling of the parent of the folder that
contains the `LANG-Editor` project, as in the SVN repository:
```
CBS-beta
- Funcons-beta
- Languages-beta
- - LANG-Folder
- - - LANG-Editor
```

(Browsing HTML files in `LANG-Folder/LANG-cbs` requires a copy of `Funcons-beta`
-- or a link to it -- one level higher in the file system.)

The dynamic features of the web pages work as intended in Safari and Eclipse.
They allow sections, comments, and rules to be collapsed (individually or
collectively), and a fixed menu provides links to `LANG-Start` and
`Funcons-Index`.

____
